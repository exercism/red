Content of this folder was moved to Red/Code repository:
https://github.com/red/code/tree/master/Library