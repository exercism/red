#!/bin/sh -l
set -x
exec bash -x -c "$1"
